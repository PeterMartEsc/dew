<template>
  <div>
    <h1>Hola Skills</h1>
  </div>
</template>
