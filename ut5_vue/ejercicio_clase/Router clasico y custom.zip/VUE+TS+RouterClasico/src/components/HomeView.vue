<template>
  <div>
    <h2>Home</h2>
    <p>Página principal</p>
  </div>
</template>

<script setup lang="ts"></script>