<template>
  <div>
    <h2>Login</h2>
    <p>Formulario de login</p>
  </div>
</template>

<script setup lang="ts"></script>