<template>
  <div>
    <h2>Register</h2>
    <p>Formulario de registro</p>
  </div>
</template>

<script setup lang="ts"></script>