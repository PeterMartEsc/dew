// Alternativia a si no funciona el servidor del Profe

// @ts-nocheck
export const productos = [
  { id: 1, title: "Teclado", price: 19.99 },
  { id: 2, title: "Ratón óptico", price: 12.49 },
  { id: 3, title: 'Monitor 24"', price: 139.9 },
  { id: 4, title: "Auriculares", price: 29.95 },
  { id: 5, title: "Webcam HD", price: 34.5 },
  { id: 6, title: "Micrófono USB", price: 45.0 },
  { id: 7, title: "Alfombrilla", price: 7.25 },
  { id: 8, title: "SSD 500GB", price: 59.99 },
  { id: 9, title: "Hub USB 4 puertos", price: 14.8 },
  { id: 10, title: "Cargador 65W", price: 24.9 },
];
