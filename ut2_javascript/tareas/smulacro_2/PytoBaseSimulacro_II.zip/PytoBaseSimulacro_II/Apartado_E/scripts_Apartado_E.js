"use strict";

/* =========================
   APARTADO (E) 2.- Validaciones
========================= */
function validaNombre($nombre) {}

function validaEmail($email) {}

function validaEdad($edad) {}

// Leer LocalStorage
function leerAlumnos() {}

// Guardar LocalStorage
function guardarAlumnos(arr) {}

/* =========================
   Render lista alumnos (E)
========================= */
function renderAlumnos(lista, $destino) {}

// Render lista productos (F)
function renderProductos(productos, $destino) {}

function abrirDetalleProducto(p) {}

/* =========================
   Init
========================= */
document.addEventListener("DOMContentLoaded", async () => {
  // *********   APARTADO (E)    ********
  // 1.- Captura submit del formulario. Prevén envío por defecto.
  // 2.- Validaciones de los campos del formulario.
  // 3.- Limpiar y renderizar lista de alumnos.
  // 4.- Cargar alumnos de LocalStorage.
  // 5.- Captura botón #btnLimpiar borrar lista y limpiar LocalStorage.
  // 6.- Cambia aspecto del formulario al hacer foco en los campos.
});
